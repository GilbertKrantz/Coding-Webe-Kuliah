#include <stdio.h>
#include <string.h>

typedef struct
{
    char title[10000];
    char artist[10000];
    int view;
}data;

struct buffer
{
    data items[100];
}buffer;


void swap(data *a, data *b) {
    data temp = *a;
    *a = *b;
    *b = temp;
} 

void bubbleSort(int structSize) {
    for (int i = 0; i < structSize; i++)
    {
        for (int j = 0; j < structSize; j++)
        {

            if (buffer.items[j].view < buffer.items[j + 1].view)
            {
                swap(&buffer.items[j], &buffer.items[j + 1]);
            }
            
            if (buffer.items[j].view == buffer.items[j + 1].view)
            {
                if (strcmp(buffer.items[j].title, buffer.items[j + 1].title) > 0)
                {
                    swap(&buffer.items[j], &buffer.items[j + 1]);
                }
            }
            
        }
    }

}

int main(int argc, char const *argv[])
{
    FILE* file;
    char ch;
    char title[10000];
    char artist[10000];
    int view;
    int structCount = 0;
    
    file = fopen("testdata.in", "r");

    if (NULL == file)
    {
        printf("File can't be Opened\n");
    }

    while (!feof(file))
    {
        fscanf(file, "%[^#]#%[^#]#%d", title, artist, &view);
        strcpy(buffer.items[structCount].title, title);
        strcpy(buffer.items[structCount].artist, artist);
        buffer.items[structCount].view = view;
        structCount++;
    }

    int structSize = structCount - 1;
    bubbleSort(structSize);
    
    

    for (int i = 0; i < structCount; i++)
    {
        printf("%s by %s - %d\n", buffer.items[i].title, buffer.items[i].artist, buffer.items[i].view);
    }
    


    return 0;
}
